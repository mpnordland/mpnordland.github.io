<?php


$options = getopt('m:t:l');
if (array_key_exists('m', $options)){
    $export_module = $options['m'];
} else {
    die("You must pass the '-m' argument with the exported Features module name");
}
$export_type = NULL;
if (array_key_exists('t', $options)){
    $export_type = $options['t'];
}
// We don't do any translating so this just returns it's argument
function t($thing){
    return $thing;
}

include_once ( "$export_module.features.fieldgroup.inc" );
include_once ( "$export_module.features.inc" );
include_once ( "$export_module.features.content.inc" );
$type_func = $export_module."_node_info";
$field_func = $export_module.'_content_default_fields';
$group_func = $export_module.'_fieldgroup_default_groups';
foreach([$type_func, $field_func, $group_func] as $func){
    if (!function_exists($func)){
        die("$func must be defined");
    }
}
//taken from http://php.net/manual/en/reserved.classes.php#113971
//gets arround stdClass not having a __set_state() method defined
//improved output formating

function export_array_helper($variable, $depth=1){
    $array = array();
    $indent = str_repeat("  ", $depth);
    foreach ($variable as $key => $value) {
        if (is_array($value)){
            $array[] = var_export($key, true).' => '.export_array_helper($value, $depth+1);
        } else if ($value instanceof stdClass) {
            $array[] = var_export($key, true).' => '.'(object) '.export_array_helper(get_object_vars($value), $depth+1);
        } else {
            $array[] = var_export($key, true).' => '.improved_var_export($value, true);
        }
    }
    if (empty($array)){
        $result = "array()";
    } else {
        $result = "array(\n".$indent.implode(",\n".$indent, $array)."\n".str_repeat("  ",$depth-1).")";
    }
    return $result;
}

function improved_var_export ($variable, $return = false) {
    if ($variable instanceof stdClass) {
        $result = '(object) '.improved_var_export(get_object_vars($variable), true);
    } else if (is_array($variable)) {
        $result = export_array_helper($variable);
    } else {
        $result = var_export($variable, true);
    }

    if (!$return) {
        print $result;
        return null;
    } else {
        return $result;
    }
}

function make_allowed_values($str) {
    $lines = explode("\n", $str);
    $options = [];
    foreach($lines as $l){
        $opt = explode('|', $l);
        if ($opt[0] == 'off'){
            $options[0] = trim($opt[1]);
        } else if( $opt[0] == 'on'){
            $options[1] = trim($opt[1]);
        }
    }
    return $options;
}

function convert_field_type($f_info){
    if ($f_info['type'] == 'text' and $f_info['widget']['type'] == 'optionwidgets_onoff'){
        return array('type'=> 'list_boolean', 'module' => 'list');
    } else if ($f_info['type'] == 'text' and $f_info['widget']['type'] == 'text_textarea'){
        return array('type'=> 'text_long', 'module'=> 'text');
    } else if ($f_info['type'] == 'filefield' and $f_info['module'] == 'filefield'){
        return array('type'=> 'file', 'module'=>'file');
    } else if ($f_info['type'] == 'location' and $f_info['module'] == 'location_cck'){
        return array('type' => 'addressfield', 'module' => 'addressfield');
    } else if ($f_info['module'] == 'cck_phone'){
        return array('type' => 'telephone', 'module' => 'telephone');
    }
    return array('type'=>$f_info['type'], 'module' => $f_info['module']);
}

function make_field_settings($f_info, $f_type_info){
    $settings = [];
    if ($f_type_info['module']=='list' and $f_type_info['type']=='list_boolean'){
        $settings['allowed_values'] = make_allowed_values($f_info['allowed_values']);
    }

    if (!empty($f_info['allowed_values_function'])){
        $settings['allowed_values_function'] = $f_info['allowed_values_function'];
    }

    if ($f_type_info['module'] == 'text' and $f_type_info['type'] == 'text') {
        $settings['max_length'] = 255;
    } else if (!empty($f_info['max_length'])){
        $settings['max_length'] = $f_info['max_length'];
    }

    if ($f_type_info['module'] == 'markup'){
        $settings['markup'] = array(
            'value' => $f_info['markup'],
            'format' => 'tinymce',
        );
    } else if ($f_type_info['module'] == 'date'){
        $settings+= array(
            'granularity' => $f_info['granularity'],
            'tz_handling' => $f_info['tz_handling'],
            'timezone_db' => $f_info['timezone_db'],
            'cache_enabled' => 0,
            'cache_count' => '4',
            'todate' => $f_info['todate'],
        );
    }
    return $settings;
}

function make_field_sql($f_info, $f_type_info){
    $field_data_name='field_data_'.$f_info['field_name'];
    $field_rev_name = 'field_revision_'.$f_info['field_name'];
    $field_value_name = $f_info['field_name'].'_value';
    $sql = array(
        'FIELD_LOAD_CURRENT' => array(
            $field_data_name => array(
                'value' => $field_value_name,
            ),
        ),
        'FIELD_LOAD_REVISION' => array(
             $field_rev_name => array(
                'value' => $field_value_name,``
            ),
        ),
    );
    if ($f_type_info['module'] == 'text'){
            $sql['FIELD_LOAD_CURRENT'][$field_data_name]['format']=$f_info['field_name'].'_format';
            $sql['FIELD_LOAD_REVISION'][$field_rev_name] = $sql['FIELD_LOAD_CURRENT'][$field_data_name];
    } else if ($f_type_info['module'] == 'addressfield'){
        $field_name = $f_info['field_name'];
        $sql['FIELD_LOAD_CURRENT'][$field_data_name] = array(
            'country' => $field_name.'_country',
            'administrative_area' => $field_name.'_administrative_area',
            'sub_administrative_area' => $field_name.'_sub_administrative_area',
            'locality' => $field_name.'_locality',
            'dependent_locality' => $field_name.'_dependent_locality',
            'postal_code' => $field_name.'_postal_code',
            'thoroughfare' => $field_name.'_thoroughfare',
            'premise' => $field_name.'_premise',
            'sub_premise' => $field_name.'_sub_premise',
            'organisation_name' => $field_name.'_organisation_name',
            'name_line' => $field_name.'_name_line',
            'first_name' => $field_name.'_first_name',
            'last_name' => $field_name.'_last_name',
            'data' => $field_name.'_data',
        );

        $sql['FIELD_LOAD_REVISION'][$field_rev_name] = $sql['FIELD_LOAD_CURRENT'][$field_data_name];
    }
    return $sql;
}

function make_field_foreign_keys($f_type_info){
    if ($f_type_info['module'] == 'text') {
        return array(
            'format' => array(
                'table' => 'filter_format',
                'columns' => array(
                    'format' => 'format',
                ),
            ),
        );
    } else if ($f_type_info['module'] == 'file'){
        return array(
            'fid' => array(
                'table' => 'file_managed',
                'columns' => array(
                    'fid' => 'fid',
                ),
            ),
        );
    }
    return array();
}

function make_field_indexes($f_type_info) {
    if ($f_type_info['module'] == 'text'){
        return array(
            'format'=> array(
              0 => 'format',
            ),
        );
    } else if ($f_type_info['module'] == 'list'){
        return array(
            'value'=> array(
              0 => 'value',
            ),
        );
    }else if ($f_type_info['module'] == 'file'){
        return array(
            'fid' => array(
                0 => 'fid',
            ),
        );
    }
    return array();
}

function make_field_columns($f_type_info){
    if ($f_type_info['module'] == 'text'){
        $value = array(
            'type' => 'varchar',
            'length' => '255',
            'not null' => FALSE,
        );

        if ($f_type_info['type'] == 'text_long'){
            $value = array(
                'type' => 'text',
                'size' => 'big',
                'not null' => FALSE,
            );
        }
        return array(
            'value' => $value,
            'format' => array(
                'type' => 'varchar',
                'length' => 255,
                'not null' => FALSE,
            ),
        );
    } else if ($f_type_info['module'] == 'list'){
        return array(
            'value' => array(
                'type' => 'int',
                'not null' => FALSE,
            ),
        );
    } else if ($f_type_info['module'] == 'date'){
        return array(
            'value' => array(
                'type' => 'datetime',
                'mysql_type' => 'datetime',
                'pgsql_type' => 'timestamp without time zone',
                'sqlite_type' => 'varchar',
                'sqlsrv_type' => 'smalldatetime',
                'not null' => FALSE,
                'sortable' => TRUE,
                'views' => TRUE,
            ),
        );
    } else if ($f_type_info['module'] == 'addressfield'){
        return array(
            'country' => array(
              'description' => 'Two letter ISO country code of this address.',
              'type' => 'varchar',
              'length' => 2,
              'not null' => FALSE,
              'default' => '',
            ),
            'administrative_area' => array(
              'description' => 'The administrative area of this address. (i.e. State/Province)',
              'type' => 'varchar',
              'length' => 255,
              'default' => '',
              'not null' => FALSE,
            ),
            'sub_administrative_area' => array(
              'description' => 'The sub administrative area of this address.',
              'type' => 'varchar',
              'length' => 255,
              'default' => '',
              'not null' => FALSE,
            ),
            'locality' => array(
              'description' => 'The locality of this address. (i.e. City)',
              'type' => 'varchar',
              'length' => 255,
              'default' => '',
              'not null' => FALSE,
            ),
            'dependent_locality' => array(
              'description' => 'The dependent locality of this address.',
              'type' => 'varchar',
              'length' => 255,
              'default' => '',
              'not null' => FALSE,
            ),
            'postal_code' => array(
              'description' => 'The postal code of this address.',
              'type' => 'varchar',
              'length' => 255,
              'default' => '',
              'not null' => FALSE,
            ),
            'thoroughfare' => array(
              'description' => 'The thoroughfare of this address. (i.e. Street address)',
              'type' => 'varchar',
              'length' => 255,
              'default' => '',
              'not null' => FALSE,
            ),
            'premise' => array(
              'description' => 'The premise of this address. (i.e. Apartment / Suite number)',
              'type' => 'varchar',
              'length' => 255,
              'default' => '',
              'not null' => FALSE,
            ),
            'sub_premise' => array(
              'description' => 'The sub_premise of this address.',
              'type' => 'varchar',
              'length' => 255,
              'default' => '',
              'not null' => FALSE,
            ),
            'organisation_name' => array(
              'description' => 'Contents of a primary OrganisationName element in the xNL XML.',
              'type' => 'varchar',
              'length' => 255,
              'not null' => FALSE,
              'default' => '',
            ),
            'name_line' => array(
              'description' => 'Contents of a primary NameLine element in the xNL XML.',
              'type' => 'varchar',
              'length' => 255,
              'not null' => FALSE,
              'default' => '',
            ),
            'first_name' => array(
              'description' => 'Contents of the FirstName element of a primary PersonName element in the xNL XML.',
              'type' => 'varchar',
              'length' => 255,
              'not null' => FALSE,
              'default' => '',
            ),
            'last_name' => array(
              'description' => 'Contents of the LastName element of a primary PersonName element in the xNL XML.',
              'type' => 'varchar',
              'length' => 255,
              'not null' => FALSE,
              'default' => '',
            ),
            'data' => array(
              'description' => 'Additional data for this address.',
              'type' => 'text',
              'size' => 'big',
              'not null' => FALSE,
              'serialize' => TRUE,
            ),
        );
    }
    return array();
}

function convert_widget_type($widget){
    $module = $widget['module'];
    $type = $widget['type'];
    if ($type == 'optionwidgets_select'){
        $module = 'select_or_other';
        $type = 'select_or_other_buttons';
    } else if ($module == 'optionwidgets'){
        $type = str_replace('widget', '', $type);
        $module = str_replace('widget', '', $module);
    } else if ($module == 'cck_phone'){
        $type = 'telephone_default';
        $module = 'telephone';
    } else if ($module == 'location_cck' and $type == 'location') {
        $type = 'addressfield_standard';
        $module = 'addressfield';
    }
    return array('type' => $type, 'module' => $module);
}

function make_instance_settings($w_type_info, $widget){
    $module = $w_type_info['module'];
    $type = $w_type_info['type'];
    $ret = array(
        'user_register_form' => FALSE,
    );
    if ($module == 'text'){
        $ret['text_processing'] = '0';
    } else if ($module == 'date'){
        $ret['default_value'] =$widget['default_value'];
        $ret['default_value_code'] = $widget['default_value_code'];
        $ret['default_value2'] = $widget['default_value2'];
        $ret['default_value_code2'] = $widget['default_value_code2'];
    } else if ($module == 'addressfield'){

    }
    return $ret;
}

function make_widget_settings($f_info, $w_type_info){
    $module = $w_type_info['module'];
    $type = $w_type_info['type'];
    $widget = $f_info['widget'];
    $ret = array(
        'label_help_description' => '',
    );
    if ($module == 'addressfield'){
        $ret += array(
            'available_countries' => array(),
            'default_country' => 'site_default',
            'format_handlers' => array(
                'address' => 'address',
                'address-hide-postal-code' => 0,
                'address-hide-street' => 0,
                'address-hide-country' => 0,
                'organisation' => 0,
                'name-full' => 0,
                'name-oneline' => 0,
                'address-optional' => 0,
            ),
        );
    } else if ($module == 'select_or_other' or $module == 'options'){
        $ret += array(
            'available_options' => $f_info['allowed_values'],
        );
    } else if ($module == 'text'){
        $ret += array(
            'maxlength_js' => 0,
            'maxlength_js_label' => 'Content limited to @limit characters, remaining: <strong>@remaining</strong>',
        );
        if ($type== 'text_textfield'){
            $ret['size'] = '60';
        } else if ($type == 'text_textarea'){
            $ret += array(
                'rows' => '5',
                'maxlength_js_enforce' => 0,
                'maxlength_js_truncate_html' => 0,
            );
        }
    } else if ($module == 'telephone'){
        $ret['placeholder'] = '';
    } else if ($module == 'date'){
        $ret += array(
            'input_format' => $widget['input_format'],
            'input_format_custom' => $widget['input_format_custom'],
            'year_range' => $widget['year_range'],
            'increment' => $widget['increment'],
            'label_position' => $widget['label_position'],
            'text_parts' => $widget['text_parts'],
            'no_fieldset' => 0,
        );
    }

    return $ret;
}

function make_widget_default_display($widget, $f_type_info){
    $module = $f_type_info['module'];
    $type = $f_type_info['type'];
    $ret = array(
        'label' => 'above',
        'type' => $module.'_default',
        'settings' => array(),
        'module' => $module,
        'weight' => $widget['weight']-5,
    );
    if ($module == 'addressfield'){
        $ret['settings'] = array(
            'use_widget_handlers' => 1,
            'format_handlers' => array(
                0 => 'address',
            ),
        );
    } else if ($module == 'telephone'){
        $ret['type'] = 'text_plain';
        $ret['module'] == 'text';
    } else if ($module == 'number'){
        $ret['type'] = 'number_integer';
        $ret['settings'] = array(
            'thousand_separator' => '',
            'decimal_separator' => '.',
            'scale' => 0,
            'prefix_suffix' => TRUE,
        );
    }
    return $ret;
}

function convert_instance_default_value($widget){
    if (!is_null($widget['default_value'])){
        return $widget['default_value'];
    } else {
        return NULL;
    }
}


$content_types = $type_func();
$fields = $field_func();
$fieldgroups = $group_func();
if(array_key_exists('l', $options)){
    foreach($content_types as $ct=> $ct_info){
        print $ct . "\n";
    }
    die();
}

$data = [];
// Build bundles
$bundles = [];
foreach ($content_types as $ct => $ct_info){
    if (!is_null($export_type)){
        if ($ct != $export_type){
            continue;
        }
    }
    $ct_info['type'] = $ct;
    $ct_info['base'] = 'node_content';
    $ct_info['module'] = 'node';
    $ct_info['custom'] = '1';
    $ct_info['modified'] = '1';
    $ct_info['locked'] = '0';
    $ct_info['disabled'] = '0';
    $ct_info['orig_type'] = $ct;
    $ct_info['disabled_changed'] = FALSE;
    $ct_info['bc_entity_type'] = 'node';
    $bundles[$ct] = (object)$ct_info;
}
$data['bundles'] = $bundles;


$d7_fields = [];
$instances = [];
$count = 0;
foreach ($fields as $f=>$f_info){
    $f_type_info = convert_field_type($f_info);
    if ($f_type_info['module'] == 'nodereference' or $f_type_info['module'] == 'userreference'){
        continue;
    }
    if (!is_null($export_type)){
        if ($f_info['type_name'] != $export_type){
            continue;
        }
    }
    $d7_field = array(
        'translatable' => '0',
        'entity_types' => array(),
        'indexes' => make_field_indexes($f_type_info),
        'field_name' => $f_info['field_name'],
        'type' => $f_type_info['type'],
        'module' => $f_type_info['module'],
        'active' => $f_info['active'],
        'locked' => '0',
        'cardinality' => '1',
        'deleted' => '0',
        'columns' => make_field_columns($f_type_info),
        'bundles' => array(
            'node' => array(
              0 => $f_info['type_name'],
            ),
        ),
    );
    $d7_field['foreign keys'] = make_field_foreign_keys($f_type_info);
    $d7_field['settings'] = make_field_settings($f_info, $f_type_info);
    $d7_field['storage'] = array(
        'type' => 'field_sql_storage',
        'settings' => array(),
        'module' => 'field_sql_storage',
        'active' => '1',
        'details' => array(
            'sql' => make_field_sql($f_info, $f_type_info),
        ),
    );

    $widget = $f_info['widget'];
    $w_type_info  = convert_widget_type($widget);
    $instance = array();
    $instance[] = array(
        'label' => $widget['label'],
        'widget' => array(
            'weight' => $widget['weight'],
            'type' => $w_type_info['type'],
            'module' => $w_type_info['module'],
            'active' => $f_info['widget_active'],
            'settings' => make_widget_settings($f_info, $w_type_info),
        ),
        'settings' => make_instance_settings($w_type_info, $widget),
        'display' => array(
            'default' => make_widget_default_display($widget, $f_type_info),
            'teaser' => array(
                'type' => 'hidden',
                'label' => 'above',
                'settings' => array(),
                'weight' => 0,
            ),
        ),
        'required' => $f_info['required'],
        'description' => $widget['description'],
        'field_name' => $f_info['field_name'],
        'entity_type' => 'node',
        'bundle' => $f_info['type_name'],
        'deleted' => '0',
    );
    if (array_key_exists('default_value', $widget)){
        $instance[0]['default_value'] = convert_instance_default_value($widget);
    }
    $d7_fields[$f_info['field_name']] = $d7_field;
    $instances[$f_info['field_name']]=$instance;
    $count++;
}
$data['fields'] = $d7_fields;
$data['instances'] = $instances;
//$data['fields'] = [];
//$data['instances'] = [];

$d7_fieldgroups = array();
foreach($fieldgroups as $fg => $group){
    if (!is_null($export_type)){
        if ($group['type_name'] != $export_type){
            continue;
        }
    }

    $group_identifier = implode('|', array($group['group_name'],'node', $group['type_name'], 'form'));
    $d7_fieldgroups[$group_identifier] = (object) array(
        'identifier' => $group_identifier,
        'group_name' => $group['group_name'],
        'entity_type' => 'node',
        'bundle' => $group['type_name'],
        'mode' => 'form',
        'parent_name' => '',
        'table' => 'field_group',
        'type' => 'Normal',
        'export_type' => 1,
        'label' => $group['label'],
        'weight' => $group['weight'],
        'children' => $group['fields'],
        'format_type' => 'fieldset',
        'format_settings' => array(
            'formatter' => 'collapsible',
            'instance_settings' => array(
                'description' => '',
                'classes' => str_replace('_', '-', $group['group_name']).' field-group-fieldset',
                'required_fields' => 1,
                'id' => '',
            ),
        ),
    );
}
$data['fieldgroups'] = $d7_fieldgroups;

print "\$data = ";
improved_var_export($data);

print ';';

