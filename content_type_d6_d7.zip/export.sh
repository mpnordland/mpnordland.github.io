#! /bin/bash
#Positional module
m=$1
copy=false
if [ "$2" == "-c" ]; then
    copy=true
else
    mkdir -p exported
fi


for ct in `php converter.php -m $m -l`
do
    if [ "$copy" = true ]; then
        php converter.php -m venture_content_types -t "$ct" | xclip
        echo "Copied "$ct" to the clipboard"
        read -rsp "Press any key to continue" -n 1
    else
        php converter.php -m venture_content_types -t "$ct" > exported/${ct}_export.txt
    fi
done

echo
echo "Finished exporting" $m
