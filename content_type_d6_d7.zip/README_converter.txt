#Usage
In d6 create a Feature module containing the content types for export and
download it. Extract the downloaded module and place converter.php in the
folder. Call the script like this:

php converter.php -m "exported_module_name" -t "content_type_name"

-m is required, -t is so you can optionally export just one content type in case
importing all of them exceeds php max execution time.

The script will write the selected content types to stdout. This can be then
redirected to a file or piped to another program.

To import, simply copy the program's output into the text box at /admin/structure/types/import
and click the import button.

To get a list of content types in the module, run 

php converter.php -m "exported_module_name" -l

#Notes
Right now it does not export node or user reference fields 

The Bundle Copy module is used to import the content types. It provides similar
functionality to the export/import of content types present in d6. It cannot
import the d6 export though, hence this script.
